package com.bankfeed.twitter;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

public class FeedFilter {
	final static Logger logger = Logger.getLogger(FeedFilter.class);

	public void filterTweets(List<String> tweetlist,String user) {

		SendMail sendMail = new SendMail();
		Boolean value;
		String keyWords = PropertyUtils.getPropertyValue("seachword");
		String toEmailId = PropertyUtils.getPropertyValue("supportmail");
		logger.debug("All the handled are :" + keyWords);
		List<String> keyWordsList = Arrays.asList(keyWords.split("~"));

		for (String tweet : tweetlist) {
			value = containsAKeyword(tweet, keyWordsList);
			if (value) {
				sendMail.sendMail(toEmailId, tweet, user);
			}

		}
	}

	public boolean containsAKeyword(String text, List<String> keywords) {
		for (String keyword : keywords) {
			if (text.toUpperCase().contains(keyword.toUpperCase())) {
				return true;
			}
		}
		return false;
	}

	/*
	 * only for testing
	 * public static boolean hasKey(String key,List keywords) { return
	 * keywords.stream().filter(key ->
	 * keywords.contains(key)).collect(Collectors.toList()).size() > 0; }
	 */

}
