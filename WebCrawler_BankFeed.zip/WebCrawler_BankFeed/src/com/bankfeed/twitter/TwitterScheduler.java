package com.bankfeed.twitter;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class TwitterScheduler implements Job {
	final static Logger logger = Logger.getLogger(TwitterScheduler.class);

	public void execute(JobExecutionContext context) throws JobExecutionException {

		ReadTweets readTweet = new ReadTweets();
		 String handlers = PropertyUtils.getPropertyValue("twitterhandles");
		// String handlers =
		// "ibankinc~stgeorgebank~CitiAustralia~nab~Bankwest~WestpacNZ~ing_aust~asbbank~kiwibanknz~anz_au~anz_nz~cua_connect~westpac~BOQ";

		//String handlers = "Test2018";
		logger.debug("All the handled are :" + handlers);
		String[] handle = handlers.split("~");
		
		for(int i=0;i<handle.length;i++) {
			System.out.println("Going to read tweet for handle "+ handle[i]);
			List<String> Tweetlist = readTweet.readTweets(handle[i]);
			FeedFilter feedFilter = new FeedFilter();
			feedFilter.filterTweets(Tweetlist,handle[i]);
			
		}
		System.out.println("Reading done");
	}
	
	public static void main(String[] args) {
		ReadTweets readTweet = new ReadTweets();
		 String handlers = PropertyUtils.getPropertyValue("twitterhandles");
		// String handlers =
		// "ibankinc~stgeorgebank~CitiAustralia~nab~Bankwest~WestpacNZ~ing_aust~asbbank~kiwibanknz~anz_au~anz_nz~cua_connect~westpac~BOQ";

		//String handlers = "Test2018";
		logger.debug("All the handled are :" + handlers);
		String[] handle = handlers.split("~");
		
		for(int i=0;i<handle.length;i++) {
			System.out.println("Going to read tweet for handle "+ handle[i]);
			List<String> Tweetlist = readTweet.readTweets(handle[i]);
			FeedFilter feedFilter = new FeedFilter();
			feedFilter.filterTweets(Tweetlist,handle[i]);
		}
		System.out.println("Reading done");
	}

}
