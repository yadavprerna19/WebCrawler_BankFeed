package com.bankfeed.twitter; 

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;
import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class SchedulerListener implements ServletContextListener {

	final static Logger logger = Logger.getLogger(SchedulerListener.class);
	public void contextInitialized(ServletContextEvent sce) {
		System.out.println("B4 registerScheduler");
		registerScheduler();		
	}

	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		
	}
	public void registerScheduler() {
		logger.debug("Staring Scheduler");
		
		JobDetail job = JobBuilder.newJob(TwitterScheduler.class).build();
		System.out.println("after job");
		CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.cronSchedule("0 0/10 * 1/1 * ? *");
		Trigger trigger = TriggerBuilder.newTrigger().withSchedule(scheduleBuilder).build();
		System.out.println("after trigger");
		
		try {
			logger.debug("Registering Scheduler");
			Scheduler scheduler = new StdSchedulerFactory().getScheduler();
			System.out.println("scheduler b4 start");
			scheduler.start();
			System.out.println("after scheduler  start");
			scheduler.scheduleJob(job,trigger);
			System.out.println("scheduleJob after");
		}catch(SchedulerException ex){
			ex.printStackTrace();
		}
	}

}
