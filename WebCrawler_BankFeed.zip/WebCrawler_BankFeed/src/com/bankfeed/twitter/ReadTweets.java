package com.bankfeed.twitter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;

public class ReadTweets {
	final static Logger logger = Logger.getLogger(ReadTweets.class);
	
	public  List<String> readTweets(String userHandle) {
		List<String> tweets  = new ArrayList<String>();
		//Map<String, String> tweetMap = new HashMap<String,String>();
		try {
			Twitter twitter = new TwitterFactory().getInstance();
			String user = userHandle;
			twitter.setOAuthConsumer("AO3v70RBbL5tI80UT4yzEPqDF","KfCEgokNT4VRdUqbA8N2ZRTSoTBW2NvF3TOjrwpPIKiNVaVuqd");
			AccessToken oauthAccessToken = new AccessToken("2409446696-wTuPG44n9Q8EsDydgTg6YyvAxMgcDI7gH51mFUk", "0FFQGn1kSRYr8L07dMihDapqxk0Liz9yP32DV0HL3x4uN");
			twitter.setOAuthAccessToken(oauthAccessToken);
			List<Status> statusList = twitter.getUserTimeline(user);
			
			
			for(Status status: statusList) {
				
				tweets.add(status.getText());
				System.out.println("---Tweet---"+status.getText());
				//logger.debug("---Tweet---"+status.getText()); 
			}
		}catch(TwitterException ex) {
			 System.out.println("Error occured "+ex);
		}		
		System.out.println("Tweets Retrieved");
		return tweets; 
	}
	
	/*public static void main(String[] args) {
		readTweets("Test20181799001");
	}*/
}
