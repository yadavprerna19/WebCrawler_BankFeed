package com.bankfeed.twitter;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class PropertyUtils {
	final static Logger logger = Logger.getLogger(PropertyUtils.class);
	public static Properties properties = new Properties();
	
	
	public static String getPropertyValue(String pKey) {
		InputStream inputStream = null;
		String value="";
		
		try {
			if(properties.isEmpty()) {
				//inputStream = PropertyUtils.class.getResourceAsStream("Twitter.properties");
				inputStream=new FileInputStream("D:\\Twitter.properties");
				properties.load(inputStream);
			}
			/*if (inputStream == null) {
				logger.debug("Sorry, unable to find File");			
			}*/
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			properties = null;
		}
		 value = properties.getProperty(pKey);
		 logger.debug("Key value pair for key is :" +  pKey + ":" + value);
		
		return value;
		
		
	}

}
