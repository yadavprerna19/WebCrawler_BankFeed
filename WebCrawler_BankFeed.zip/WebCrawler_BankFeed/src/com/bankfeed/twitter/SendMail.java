package com.bankfeed.twitter;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMail {

	public  void sendMail(String toEmailId, String msg, String user) {

		String recipient = toEmailId;
		String Sender = "yodleetest2018@gmail.com";
		String host = "127.0.0.1";

		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
		props.put("mail.smtp.starttls.enable", "true");

		try {
			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				@Override
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication("yodleetest2018@gmail.com", "Computer2@");
				}
			});
			System.out.println("Getting Session");

			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(Sender));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
			message.setSubject("Failure probability for : " + user);
			message.setText(msg);
			Transport.send(message);

			System.out.println("Mail successfully sent."+" user: "+ user+" msg: " + msg);

		} catch (MessagingException ex) {
			System.out.println("failed");
			ex.printStackTrace();

		}

	}

	/*
	 * public static void main(String[] args) { sendMail("yadav.prerna19@gmail.com",
	 * "hello prerna!hello hello prerna"); }
	 */

}
