package com.bankfeed.restAPI;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;

import com.bankfeed.twitter.ReadTweets;

import twitter4j.JSONArray;
import twitter4j.JSONObject;

@Path("/crawler")
public class RetrieveTweets {
	
	@Path("/get/{handleId}")
	@GET
	@Consumes("text/plain")
	@Produces("text/plain")
	public String getTweetsById(@PathParam("handleId") String handleId) {
		ReadTweets readTweet = new ReadTweets();
		System.out.println("Request came in is :"+ handleId);
		System.out.println("Going to read tweet for handle " + handleId);
		List<String> tweetList = readTweet.readTweets(handleId);
		return tweetList.toString();

	}
	
@Path("/post/getAll")
@Consumes("application/json")
@Produces("application/json")
@POST
public String getAllTweets(String twitterHandles,@Context HttpServletRequest request) {
	ReadTweets readTweet = new ReadTweets();
	JSONObject jsonResponse = new JSONObject();
	System.out.println("Request came in is :"+ twitterHandles);
	try {
	JSONObject jsonobj = new JSONObject(twitterHandles);
	JSONArray handleIds = jsonobj.getJSONArray("twitterHandles");
	//String handlers = PropertyUtils.getPropertyValue("twitterhandles");
	
	for(int i = 0;i<handleIds.length();i++ ) {
	System.out.println("Going to read tweet for handle " + handleIds.get(i).toString());
	List<String> tweetList = readTweet.readTweets(handleIds.get(i).toString());
	jsonResponse.put(handleIds.get(i).toString(), tweetList.toString());
	}
	
	}
	catch(Exception e)
	{
		
	}
	return jsonResponse.toString();
	
}

	/*public static void main(String[] args) throws JSONException {
		ReadTweets readTweet = new ReadTweets();
		
		JSONObject jsonobj = new JSONObject("{ \r\n" + 
				"  'twitterHandles': [\r\n" + 
				"    'Test20181799001',\r\n" + 
				"    'anz_au',\r\n" + 
				"   'WestpacNZ'\r\n" + 
				"  ]\r\n" + 
				"}");
		JSONArray handleIds = jsonobj.getJSONArray("twitterHandles");
		//String handlers = PropertyUtils.getPropertyValue("twitterhandles");
		JSONObject jsonResponse = new JSONObject();
		for(int i = 0;i<handleIds.length();i++ ) {
		System.out.println("Going to read tweet for handle " + handleIds.get(i).toString());
		List<String> tweetList = readTweet.readTweets(handleIds.get(i).toString());
		jsonResponse.put(handleIds.get(i).toString(), tweetList.toString());
		}		
		System.out.println(jsonResponse.toString());
}*/
	
}